create
    definer = root@localhost procedure preleva_fermata(IN var_idtratta tinyint)
BEGIN
declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level repeatable read;
set transaction read only;
start transaction;
    
    select Fermata_Codice, Longitudine, Latitudine
    from Effettua join Fermata on Fermata_Codice = Codice
    where Tratta_ID = var_idtratta
    order by Indice;

commit;
    
END;

grant execute on procedure preleva_fermata to login;

