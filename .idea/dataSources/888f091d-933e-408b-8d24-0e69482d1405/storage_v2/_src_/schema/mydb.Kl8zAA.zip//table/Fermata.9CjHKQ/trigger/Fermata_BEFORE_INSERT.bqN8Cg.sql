create definer = root@localhost trigger Fermata_BEFORE_INSERT
    before insert
    on Fermata
    for each row
BEGIN

IF NOT (char_length(new.codice) = 5 and new.codice REGEXP '^[0-9]+$') THEN
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT = 'Formato codice fermata non valido.';
END IF;
    

END;

