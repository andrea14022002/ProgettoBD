create definer = root@localhost trigger Conducente_BEFORE_INSERT
    before insert
    on Conducente
    for each row
BEGIN

IF NOT NEW.CF REGEXP '^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$' THEN
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT = 'Codice Fiscale non valido.';
END IF;
    
END;

