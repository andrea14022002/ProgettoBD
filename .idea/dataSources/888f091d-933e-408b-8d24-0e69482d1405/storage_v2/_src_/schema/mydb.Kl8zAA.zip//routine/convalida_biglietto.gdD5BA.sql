create
    definer = root@localhost procedure convalida_biglietto(IN var_numero int)
BEGIN

declare var_tipo varchar(12);
    declare var_count INT;

    declare exit handler for sqlexception
    begin
        rollback;
        resignal;
    end;

set transaction isolation level serializable;
    set transaction read only;
    start transaction;
    
    select Tipo, count(*)
    into var_tipo, var_count
    FROM Biglietto
    WHERE Numero = var_numero AND Valido = 1;

    if var_count = 0 then
        signal sqlstate '45000'
        set message_text = 'Biglietto non valido.';
        
    elseif var_tipo = 'Standard' then
        update Biglietto
        set Valido = 0
        where Numero = var_numero;
    
    elseif var_tipo = 'Abbonamento' then
        update Abbonato
        set UltimoUtilizzo = current_date()
        where Abbonato.Biglietto_Numero = var_numero;
    end if;

    COMMIT;

END;

grant execute on procedure convalida_biglietto to viaggiatore;

