create
    definer = root@localhost procedure lista_tratte(IN var_fermata int)
BEGIN

    declare exit handler for sqlexception

begin
rollback;
resignal;
end;

set transaction isolation level read committed;
set transaction read only;
start transaction;

select Numero, Capolinea_Da, Capolinea_A, Ora
from VeicoloinCorsa join Effettua on Tratta = Tratta_ID join Tratta on Tratta_ID = ID
where Fermata_Codice = var_fermata and Giorno = dayname(now()) and Partito = 0 and Ora >= current_time()
    order by Numero;

commit;
END;

grant execute on procedure lista_tratte to viaggiatore;

