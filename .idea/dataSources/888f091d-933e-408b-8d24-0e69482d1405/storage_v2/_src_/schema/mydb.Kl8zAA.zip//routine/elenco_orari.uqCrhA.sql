create
    definer = root@localhost procedure elenco_orari(IN var_conducente varchar(16))
BEGIN
    
declare exit handler for sqlexception
    begin
rollback;
resignal;
end;
    
    set transaction isolation level read committed;
    set transaction read only;
    start transaction;

select Giorno, Ora
from VeicoloinCorsa
where CF = var_conducente and Partito = 0
group by Giorno;
    
commit;
END;

grant execute on procedure elenco_orari to conducente;

