create
    definer = root@localhost procedure aggiorna_patente(IN var_conducente varchar(20), IN var_numero varchar(10),
                                                        IN var_scadenza date)
BEGIN

declare exit handler for sqlexception

    begin
rollback;
resignal;
     end;

set transaction isolation level read committed;
    set transaction read only;
start transaction;
    
update Conducente
set NumeroPatente = var_numero and ScadenzaPatente = var_scadenza
where CF = var_conducente;

commit;


END;

grant execute on procedure aggiorna_patente to conducente;

