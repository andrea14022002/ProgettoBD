create
    definer = root@localhost procedure elenco_scadenze_patente()
BEGIN

declare exit handler for sqlexception
    begin
rollback;
resignal;
end;
    
    set transaction isolation level read uncommitted;
    set transaction read only;
    start transaction;
    
    select CF, NumeroPatente, ScadenzaPatente
    from Conducente;
    
commit;
END;

grant execute on procedure elenco_scadenze_patente to gestore;

