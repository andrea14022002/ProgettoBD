create
    definer = root@localhost procedure registra_conducente(IN var_CF varchar(20), IN var_nome varchar(45),
                                                           IN var_cognome varchar(45), IN var_patente varchar(10),
                                                           IN var_scadenza date, IN var_luogo varchar(45),
                                                           IN var_data date, IN var_username varchar(45))
BEGIN

 insert into Conducente(CF, Nome, Cognome, NumeroPatente, ScadenzaPatente, LuogoNascita, DataNascita, Username) values (var_CF, var_nome, var_cognome, var_patente, var_scadenza, var_luogo, var_data, var_username);

END;

grant execute on procedure registra_conducente to gestore;

