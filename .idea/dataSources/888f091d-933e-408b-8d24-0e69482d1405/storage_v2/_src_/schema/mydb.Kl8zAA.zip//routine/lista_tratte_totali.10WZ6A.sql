create
    definer = root@localhost procedure lista_tratte_totali()
BEGIN

    declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level read uncommitted;
set transaction read only;
start transaction;
    
    select *
    from Tratta;

END;

grant execute on procedure lista_tratte_totali to gestore;

