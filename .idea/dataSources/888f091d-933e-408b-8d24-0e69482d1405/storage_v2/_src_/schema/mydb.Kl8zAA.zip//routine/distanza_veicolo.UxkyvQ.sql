create
    definer = root@localhost procedure distanza_veicolo(IN var_fermata int, IN var_idTratta tinyint)
BEGIN

    declare var_index int;
    
declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level read committed;
set transaction read only;
start transaction;

    select count(*)
    into var_index
    from Effettua
    where Tratta_ID = var_idTratta;
    
    select ID, Numero, (Indice-UltimaFermata) as Distanza
    from VeicoloinCorsa join Effettua on Tratta = Tratta_ID
    where Tratta = var_idTratta and Fermata_Codice = var_fermata and UltimaFermata < Indice 
    and Indice != var_index and Veicolo in (select Veicolo 
from VeicoloinCorsa 
where Partito = 1 and Giorno = current_date());

commit;


END;

grant execute on procedure distanza_veicolo to viaggiatore;

