create
    definer = root@localhost procedure aggiorna_partito(IN var_giorno varchar(45), IN var_ora time, IN var_veicolo int)
BEGIN
declare exit handler for sqlexception
    begin
rollback;
resignal;
end;
    
    set transaction isolation level serializable;
    start transaction;
    
    update VeicoliinCorsa
    set Partito = 1
    where Giorno = var_giorno and Ora = var_ora and Veicolo = var_veicolo;
 
 commit;
 
END;

