create definer = root@localhost trigger Tratta_BEFORE_INSERT
    before insert
    on Tratta
    for each row
BEGIN

    declare numero_tratte int;
    declare capolinea_da1 int(5);
    declare capolinea_a1 int(5);
    
select count(*)
    into numero_tratte
    from Tratta
    where Numero = New.Numero;
    
    
    if numero_tratte >= 2 then
signal sqlstate '45000'
        set message_text = 'Non è possibile inserire la tratta. Numero tratta già utilizzato.';
END IF;
END;

