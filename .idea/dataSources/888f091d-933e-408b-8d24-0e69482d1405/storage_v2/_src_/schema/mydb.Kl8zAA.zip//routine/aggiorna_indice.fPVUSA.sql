create
    definer = root@localhost procedure aggiorna_indice(IN var_giorno varchar(45), IN var_ora time, IN var_veicolo int,
                                                       IN var_index int)
BEGIN
declare exit handler for sqlexception
    begin
rollback;
resignal;
end;
    
    set transaction isolation level serializable;
    start transaction;

    update VeicoliinCorsa
    set UltimeFermata = var_index
    where Giorno = var_giorno and Ora = var_ora and Veicolo = var_veicolo and Partito = 1;
    
commit;
    
END;

