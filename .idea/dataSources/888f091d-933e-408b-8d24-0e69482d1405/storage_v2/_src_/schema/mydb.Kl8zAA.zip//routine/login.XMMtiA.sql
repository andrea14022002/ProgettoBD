create
    definer = root@localhost procedure login(IN var_username varchar(45), IN var_pass varchar(45), OUT var_role int,
                                             OUT var_CF varchar(16))
BEGIN

declare var_user_role ENUM('Conducente','Gestore','Viaggiatore');
    
    select Ruolo 
    from Utenti
where 'Username' = var_username and 'Password' = md5(var_pass)
    into var_user_role;
    
    if var_user_role = 'Conducente' then
set var_role = 1;
        select CF from Conducenti
        where 'Username' = var_username
        into var_CF;

    elseif var_user_role = 'Gestore' then
set var_role = 2;
        
elseif var_user_role = 'Viaggiatore' then
set var_role = 3;

    else
set var_role = 0;
end if;

    
END;

grant execute on procedure login to login;

