create
    definer = root@localhost procedure assegna_conducente_corsa(IN var_CF varchar(20), IN var_veicolo smallint,
                                                                IN var_giorno varchar(45), IN var_ora time)
BEGIN

declare exit handler for sqlexception

    begin
rollback;
resignal;
end;

set transaction isolation level repeatable read;
    set transaction read only;
start transaction;
    
update VeicoloinCorsa
set  Conducente = var_CF
where Veicolo = var_veicolo and Giorno = var_giorno and Ora = var_ora;

commit;


END;

grant execute on procedure assegna_conducente_corsa to gestore;

