create definer = root@localhost trigger Conducente_BEFORE_UPDATE
    before update
    on Conducente
    for each row
BEGIN

IF NOT NEW.NumeroPatente REGEXP '^[A-Za-z0-9]{5,10}$' THEN
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT = 'Formato del numero di patente non valido.';
END IF;
    

END;

