create
    definer = root@localhost procedure aggiungi_fermata_tratta(IN var_fermata int, IN var_indice int, IN var_tratta tinyint)
BEGIN

declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level serializable;
start transaction;

update Effettua
set indice = indice +1
where Tratta_ID = var_tratta and indice >= var_indice;
 
insert into Effettua(Indice, Fermata_Codice, Tratta_ID) values (var_indice, var_fermata, var_tratta); 
  


commit;

END;

grant execute on procedure aggiungi_fermata_tratta to gestore;

