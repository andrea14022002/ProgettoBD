create definer = root@localhost event biglietti_non_validi on schedule
    every '30' DAY
        starts '2024-07-16 12:09:56'
    on completion preserve
    enable
    do
    begin
delete from Biglietto where Valido = 0;
end;

