create definer = root@localhost event controllo_abbonamento on schedule
    every '1' DAY
        starts '2025-06-12 00:01:00'
    on completion preserve
    enable
    do
    begin
update Biglietto
    join Abbonato on Numero = Biglietto_Numero
    set Valido = 0
    where DataScadenza < curdate() ;
    
end;

