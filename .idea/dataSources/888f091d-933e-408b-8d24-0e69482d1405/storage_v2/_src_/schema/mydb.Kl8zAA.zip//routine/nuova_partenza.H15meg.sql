create
    definer = root@localhost procedure nuova_partenza(IN var_veicolo smallint, IN var_tratta tinyint,
                                                      IN var_giorno varchar(45), IN var_orario time,
                                                      IN var_CF varchar(20))
BEGIN

    declare var_count int;
    
declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level serializable;
set transaction read only;
start transaction;

    select count(*)
    into var_count
    from VeicoloinCorsa as V
    where V.Veicolo = var_veicolo and V.Giorno = var_giorno and V.Partito = 1 
and V.Ora = (var_orario - interval 30 minute)
        and V.UltimaFermata != (select count(*)
from Effettua
where V.Tratta = Tratta_ID);
    
    if var_count > 0 then
signal sqlstate '45000'
        set message_text = 'Il veicolo è in corsa su una tratta. Non è possibile inserire orario';
else
DELETE FROM VeicoloinCorsa
WHERE Veicolo = var_veicolo and Giorno = var_giorno and Ora between var_orario - interval 30 minute and var_orario + interval 30 minute;
        
        insert into VeicoloinCorsa(Giorno, Ora, Veicolo, Tratta, Partito, UltimaFermata, Conducente) values (var_giorno, var_ora, var_veicolo, var_tratta, 0, NULL, var_CF); 
end if;
    

commit;
END;

grant execute on procedure nuova_partenza to gestore;

