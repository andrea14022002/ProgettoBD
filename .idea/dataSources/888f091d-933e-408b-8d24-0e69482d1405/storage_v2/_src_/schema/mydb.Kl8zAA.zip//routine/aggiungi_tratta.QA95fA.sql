create
    definer = root@localhost procedure aggiungi_tratta(IN var_ID tinyint, IN var_num smallint, IN var_partenza int,
                                                       IN var_destinazione int)
BEGIN

insert into Tratta(ID, Numero, Capolinea_Da, Capolinea_A) values (var_ID, var_num, var_partenza, var_destinazione); 

END;

grant execute on procedure aggiungi_tratta to gestore;

