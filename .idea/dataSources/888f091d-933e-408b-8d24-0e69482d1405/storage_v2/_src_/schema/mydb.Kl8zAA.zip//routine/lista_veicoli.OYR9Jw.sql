create
    definer = root@localhost procedure lista_veicoli(IN var_fermata int)
BEGIN

declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level repeatable read;
set transaction read only;
start transaction;

    select T.Numero, (Indice-UltimaFermata) as Distanza, T.Capolinea_A as Destinazione
    from VeicoloinCorsa as V join Effettua as E on Tratta = Tratta_ID join Tratta as T on Tratta_ID = ID
    where Fermata_Codice = var_fermata and UltimaFermata < Indice 
and Partito = 1 and Giorno = dayname(now())
                and Indice != (select count(*)
from Effettua join Tratta on Tratta_ID = ID
                                where T.ID = ID)
order by Numero;


commit;
END;

grant execute on procedure lista_veicoli to viaggiatore;

