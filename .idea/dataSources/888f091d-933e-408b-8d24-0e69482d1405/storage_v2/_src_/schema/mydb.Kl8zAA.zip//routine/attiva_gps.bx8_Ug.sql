create
    definer = root@localhost procedure attiva_gps()
BEGIN

declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level read committed;
set transaction read only;
start transaction;
    
    select Giorno, Ora, Veicolo, Tratta, Conducente
    from VeicoloinCorsa
    where Giorno = dayname(now());

commit;
END;

grant execute on procedure attiva_gps to login;

