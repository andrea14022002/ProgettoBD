create
    definer = root@localhost procedure prossima_partenza(IN var_conducente varchar(16))
BEGIN

declare exit handler for sqlexception
begin
rollback;
resignal;
end;

set transaction isolation level read committed;
set transaction read only;
start transaction;
 
select Giorno, Ora
from VeicoloinCorsa
where Conducente = var_conducente and Giorno = dayname(now()) and Ora >= current_time();


commit;
END;

grant execute on procedure prossima_partenza to conducente;

